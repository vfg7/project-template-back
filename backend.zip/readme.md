backend simples pra interagir com o front end em https://github.com/vfg7/project-template-front

clone a pasta
vá ao diretório e execute no terminal npm install e dps npm start. Por default, o projeto se comunica pela porta 3001